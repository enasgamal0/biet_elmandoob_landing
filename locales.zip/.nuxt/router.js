import Vue from 'vue'
import Router from 'vue-router'
import { normalizeURL, decode } from 'ufo'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _3d10831b = () => interopDefault(import('..\\pages\\contact.vue' /* webpackChunkName: "pages/contact" */))
const _62019024 = () => interopDefault(import('..\\pages\\delete_account.vue' /* webpackChunkName: "pages/delete_account" */))
const _47789b8d = () => interopDefault(import('..\\pages\\index.vue' /* webpackChunkName: "pages/index" */))
const _46a3cbf2 = () => interopDefault(import('..\\pages\\policy.vue' /* webpackChunkName: "pages/policy" */))
const _1d134c7c = () => interopDefault(import('..\\pages\\terms.vue' /* webpackChunkName: "pages/terms" */))
const _e46fd42c = () => interopDefault(import('..\\pages\\e-invoice\\_id.vue' /* webpackChunkName: "pages/e-invoice/_id" */))
const _1e5d5c8a = () => interopDefault(import('..\\pages\\e-invoice\\_w\\index.vue' /* webpackChunkName: "pages/e-invoice/_w/index" */))

const emptyFn = () => {}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: '/',
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/contact",
    component: _3d10831b,
    name: "contact___ar"
  }, {
    path: "/delete_account",
    component: _62019024,
    name: "delete_account___ar"
  }, {
    path: "/en",
    component: _47789b8d,
    name: "index___en"
  }, {
    path: "/policy",
    component: _46a3cbf2,
    name: "policy___ar"
  }, {
    path: "/terms",
    component: _1d134c7c,
    name: "terms___ar"
  }, {
    path: "/en/contact",
    component: _3d10831b,
    name: "contact___en"
  }, {
    path: "/en/delete_account",
    component: _62019024,
    name: "delete_account___en"
  }, {
    path: "/en/policy",
    component: _46a3cbf2,
    name: "policy___en"
  }, {
    path: "/en/terms",
    component: _1d134c7c,
    name: "terms___en"
  }, {
    path: "/en/e-invoice/:id?",
    component: _e46fd42c,
    name: "e-invoice-id___en"
  }, {
    path: "/en/e-invoice/:w",
    component: _1e5d5c8a,
    name: "e-invoice-w___en"
  }, {
    path: "/e-invoice/:id?",
    component: _e46fd42c,
    name: "e-invoice-id___ar"
  }, {
    path: "/e-invoice/:w",
    component: _1e5d5c8a,
    name: "e-invoice-w___ar"
  }, {
    path: "/",
    component: _47789b8d,
    name: "index___ar"
  }],

  fallback: false
}

export function createRouter (ssrContext, config) {
  const base = (config._app && config._app.basePath) || routerOptions.base
  const router = new Router({ ...routerOptions, base  })

  // TODO: remove in Nuxt 3
  const originalPush = router.push
  router.push = function push (location, onComplete = emptyFn, onAbort) {
    return originalPush.call(this, location, onComplete, onAbort)
  }

  const resolve = router.resolve.bind(router)
  router.resolve = (to, current, append) => {
    if (typeof to === 'string') {
      to = normalizeURL(to)
    }
    return resolve(to, current, append)
  }

  return router
}
