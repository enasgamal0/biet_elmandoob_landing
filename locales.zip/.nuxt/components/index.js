export { default as CarouselsAppScreensCarousel } from '../..\\components\\carousels\\AppScreensCarousel.vue'
export { default as FormInputsBaseColorPicker } from '../..\\components\\FormInputs\\BaseColorPicker.vue'
export { default as FormInputsBaseInput } from '../..\\components\\FormInputs\\BaseInput.vue'
export { default as FormInputsBaseSelectInput } from '../..\\components\\FormInputs\\BaseSelectInput.vue'
export { default as GeneralAboutSection } from '../..\\components\\general\\AboutSection.vue'
export { default as GeneralAppScreensSection } from '../..\\components\\general\\AppScreensSection.vue'
export { default as GeneralDownloadApp } from '../..\\components\\general\\DownloadApp.vue'
export { default as GeneralHeroSection } from '../..\\components\\general\\HeroSection.vue'
export { default as GeneralServicesSection } from '../..\\components\\general\\ServicesSection.vue'
export { default as StructureTheFooter } from '../..\\components\\structure\\TheFooter.vue'
export { default as StructureTheNavbar } from '../..\\components\\structure\\TheNavbar.vue'
export { default as UiBaseButton } from '../..\\components\\ui\\BaseButton.vue'
export { default as UiMainLoader } from '../..\\components\\ui\\MainLoader.vue'

// nuxt/nuxt.js#8607
function wrapFunctional(options) {
  if (!options || !options.functional) {
    return options
  }

  const propKeys = Array.isArray(options.props) ? options.props : Object.keys(options.props || {})

  return {
    render(h) {
      const attrs = {}
      const props = {}

      for (const key in this.$attrs) {
        if (propKeys.includes(key)) {
          props[key] = this.$attrs[key]
        } else {
          attrs[key] = this.$attrs[key]
        }
      }

      return h(options, {
        on: this.$listeners,
        attrs,
        props,
        scopedSlots: this.$scopedSlots,
      }, this.$slots.default)
    }
  }
}
