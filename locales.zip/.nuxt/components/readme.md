# Discovered Components

This is an auto-generated list of components discovered by [nuxt/components](https://github.com/nuxt/components).

You can directly use them in pages and other components without the need to import them.

**Tip:** If a component is conditionally rendered with `v-if` and is big, it is better to use `Lazy` or `lazy-` prefix to lazy load.

- `<CarouselsAppScreensCarousel>` | `<carousels-app-screens-carousel>` (components/carousels/AppScreensCarousel.vue)
- `<FormInputsBaseColorPicker>` | `<form-inputs-base-color-picker>` (components/FormInputs/BaseColorPicker.vue)
- `<FormInputsBaseInput>` | `<form-inputs-base-input>` (components/FormInputs/BaseInput.vue)
- `<FormInputsBaseSelectInput>` | `<form-inputs-base-select-input>` (components/FormInputs/BaseSelectInput.vue)
- `<GeneralAboutSection>` | `<general-about-section>` (components/general/AboutSection.vue)
- `<GeneralAppScreensSection>` | `<general-app-screens-section>` (components/general/AppScreensSection.vue)
- `<GeneralDownloadApp>` | `<general-download-app>` (components/general/DownloadApp.vue)
- `<GeneralHeroSection>` | `<general-hero-section>` (components/general/HeroSection.vue)
- `<GeneralServicesSection>` | `<general-services-section>` (components/general/ServicesSection.vue)
- `<StructureTheFooter>` | `<structure-the-footer>` (components/structure/TheFooter.vue)
- `<StructureTheNavbar>` | `<structure-the-navbar>` (components/structure/TheNavbar.vue)
- `<UiBaseButton>` | `<ui-base-button>` (components/ui/BaseButton.vue)
- `<UiMainLoader>` | `<ui-main-loader>` (components/ui/MainLoader.vue)
