import Vue from 'vue'
import VueSlickCarousel from 'vue-slick-carousel'

Vue.component('SlickCarousel', VueSlickCarousel)